package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("KaamDost", appName)
  }

  @Test
  fun `test voice keyword matching`() {
    val repo = com.example.data.KaamDostRepository()
    val matchElectrician = repo.matchServiceFromVoice("Mujhe electrician chahiye")
    assertEquals(com.example.data.ServiceType.ELECTRICIAN, matchElectrician)

    val matchAC = repo.matchServiceFromVoice("AC theek karwana hai")
    assertEquals(com.example.data.ServiceType.AC, matchAC)

    val matchPlumber = repo.matchServiceFromVoice("Plumber bhai ko bulao")
    assertEquals(com.example.data.ServiceType.PLUMBER, matchPlumber)
  }
}
