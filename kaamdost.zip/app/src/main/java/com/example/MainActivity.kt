package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*

sealed class Screen {
    object Home : Screen()
    object Search : Screen()
    object Bookings : Screen()
    object Profile : Screen()
    data class ServiceDetail(val serviceType: ServiceType) : Screen()
    data class WorkerProfile(val worker: Worker) : Screen()
    data class BookingFlow(val worker: Worker) : Screen()
}

class MainActivity : ComponentActivity() {

    private val repository = KaamDostRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KaamDostApp(repository = repository)
            }
        }
    }
}

@Composable
fun KaamDostApp(repository: KaamDostRepository) {
    val context = LocalContext.current

    val currentLanguage by repository.selectedLanguage.collectAsStateWithLifecycle()
    val selectedCity by repository.selectedCity.collectAsStateWithLifecycle()
    val searchQuery by repository.searchQuery.collectAsStateWithLifecycle()
    val allWorkers by repository.workers.collectAsStateWithLifecycle()
    val bookings by repository.bookings.collectAsStateWithLifecycle()
    val chatMap by repository.chatMessages.collectAsStateWithLifecycle()

    var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }
    val screenStack = remember { mutableStateListOf<Screen>(Screen.Home) }

    // Dialogs state
    var showVoiceDialog by remember { mutableStateOf(false) }
    var showCityDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var videoWorker by remember { mutableStateOf<Worker?>(null) }
    var chatWorker by remember { mutableStateOf<Worker?>(null) }

    fun navigateTo(screen: Screen) {
        screenStack.add(screen)
        currentScreen = screen
    }

    fun navigateBack() {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.lastIndex)
            currentScreen = screenStack.last()
        }
    }

    BackHandler(enabled = screenStack.size > 1) {
        navigateBack()
    }

    // Voice Dialog
    if (showVoiceDialog) {
        VoiceSearchDialog(
            onDismiss = { showVoiceDialog = false },
            onServiceSelected = { service ->
                showVoiceDialog = false
                navigateTo(Screen.ServiceDetail(service))
            },
            onSpokenPrompt = { prompt ->
                val matched = repository.matchServiceFromVoice(prompt)
                if (matched != null) {
                    Toast.makeText(context, "Matched: ${matched.titleEn} (${matched.titleUrdu})", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // City Dialog
    if (showCityDialog) {
        CitySelectionDialog(
            currentCity = selectedCity,
            onCitySelected = { repository.setCity(it) },
            onDismiss = { showCityDialog = false }
        )
    }

    // Language Dialog
    if (showLanguageDialog) {
        LanguageSelectionDialog(
            currentLanguage = currentLanguage,
            onLanguageSelected = { repository.setLanguage(it) },
            onDismiss = { showLanguageDialog = false }
        )
    }

    // Video Player Modal
    if (videoWorker != null) {
        VideoIntroModal(
            worker = videoWorker!!,
            onDismiss = { videoWorker = null },
            onBookClick = {
                val w = videoWorker!!
                videoWorker = null
                navigateTo(Screen.BookingFlow(w))
            }
        )
    }

    // In-App Chat Dialog
    if (chatWorker != null) {
        val w = chatWorker!!
        val msgs = chatMap[w.id] ?: emptyList()
        WorkerChatDialog(
            worker = w,
            messages = msgs,
            onDismiss = { chatWorker = null },
            onSendMessage = { text ->
                repository.sendChatMessage(w.id, text)
            }
        )
    }

    val isTopLevelScreen = currentScreen is Screen.Home ||
            currentScreen is Screen.Search ||
            currentScreen is Screen.Bookings ||
            currentScreen is Screen.Profile

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (isTopLevelScreen) {
                KaamDostTopBar(
                    currentLanguage = currentLanguage,
                    selectedCity = selectedCity,
                    onLanguageClick = { showLanguageDialog = true },
                    onCityClick = { showCityDialog = true },
                    onEmergencyClick = {
                        navigateTo(Screen.ServiceDetail(ServiceType.EMERGENCY))
                    }
                )
            }
        },
        bottomBar = {
            if (isTopLevelScreen) {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    // 1. Home
                    NavigationBarItem(
                        selected = currentScreen is Screen.Home,
                        onClick = {
                            screenStack.clear()
                            screenStack.add(Screen.Home)
                            currentScreen = Screen.Home
                        },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen is Screen.Home) Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = "Home"
                            )
                        },
                        label = {
                            Text(
                                text = "Home • ہوم",
                                fontWeight = if (currentScreen is Screen.Home) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = KaamGreenDark,
                            selectedTextColor = KaamGreenDark,
                            indicatorColor = KaamYellow
                        ),
                        modifier = Modifier.testTag("nav_item_home")
                    )

                    // 2. Search
                    NavigationBarItem(
                        selected = currentScreen is Screen.Search,
                        onClick = {
                            if (currentScreen !is Screen.Search) {
                                navigateTo(Screen.Search)
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen is Screen.Search) Icons.Filled.Search else Icons.Outlined.Search,
                                contentDescription = "Search"
                            )
                        },
                        label = {
                            Text(
                                text = "Search • تلاش",
                                fontWeight = if (currentScreen is Screen.Search) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = KaamGreenDark,
                            selectedTextColor = KaamGreenDark,
                            indicatorColor = KaamYellow
                        ),
                        modifier = Modifier.testTag("nav_item_search")
                    )

                    // 3. Bookings
                    NavigationBarItem(
                        selected = currentScreen is Screen.Bookings,
                        onClick = {
                            if (currentScreen !is Screen.Bookings) {
                                navigateTo(Screen.Bookings)
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen is Screen.Bookings) Icons.Filled.CalendarMonth else Icons.Outlined.CalendarMonth,
                                contentDescription = "Bookings"
                            )
                        },
                        label = {
                            Text(
                                text = "Bookings • بکنگ",
                                fontWeight = if (currentScreen is Screen.Bookings) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = KaamGreenDark,
                            selectedTextColor = KaamGreenDark,
                            indicatorColor = KaamYellow
                        ),
                        modifier = Modifier.testTag("nav_item_bookings")
                    )

                    // 4. Profile
                    NavigationBarItem(
                        selected = currentScreen is Screen.Profile,
                        onClick = {
                            if (currentScreen !is Screen.Profile) {
                                navigateTo(Screen.Profile)
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen is Screen.Profile) Icons.Filled.Person else Icons.Outlined.Person,
                                contentDescription = "Profile"
                            )
                        },
                        label = {
                            Text(
                                text = "Profile • پروفائل",
                                fontWeight = if (currentScreen is Screen.Profile) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = KaamGreenDark,
                            selectedTextColor = KaamGreenDark,
                            indicatorColor = KaamYellow
                        ),
                        modifier = Modifier.testTag("nav_item_profile")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = currentScreen, label = "screen_crossfade") { screen ->
                when (screen) {
                    is Screen.Home -> {
                        HomeScreen(
                            currentLanguage = currentLanguage,
                            selectedCity = selectedCity,
                            searchQuery = searchQuery,
                            onSearchQueryChange = { repository.setSearchQuery(it) },
                            onMicClick = { showVoiceDialog = true },
                            onServiceClick = { service ->
                                navigateTo(Screen.ServiceDetail(service))
                            },
                            onWorkerClick = { worker ->
                                navigateTo(Screen.WorkerProfile(worker))
                            },
                            onBookWorker = { worker ->
                                navigateTo(Screen.BookingFlow(worker))
                            },
                            onChatWorker = { worker ->
                                chatWorker = worker
                            },
                            onVideoIntroWorker = { worker ->
                                videoWorker = worker
                            },
                            topWorkers = allWorkers,
                            onRegisterWorkerClick = {
                                navigateTo(Screen.Profile)
                            }
                        )
                    }

                    is Screen.Search -> {
                        SearchTabScreen(
                            searchQuery = searchQuery,
                            onSearchQueryChange = { repository.setSearchQuery(it) },
                            onMicClick = { showVoiceDialog = true },
                            selectedCity = selectedCity,
                            workers = allWorkers,
                            onWorkerClick = { worker ->
                                navigateTo(Screen.WorkerProfile(worker))
                            },
                            onBookWorker = { worker ->
                                navigateTo(Screen.BookingFlow(worker))
                            },
                            onChatWorker = { worker ->
                                chatWorker = worker
                            },
                            onVideoIntroWorker = { worker ->
                                videoWorker = worker
                            },
                            onServiceTagClick = { service ->
                                navigateTo(Screen.ServiceDetail(service))
                            }
                        )
                    }

                    is Screen.Bookings -> {
                        BookingsTabScreen(
                            bookings = bookings,
                            onStatusChange = { id, status ->
                                repository.updateBookingStatus(id, status)
                            },
                            onBookNewClick = {
                                screenStack.clear()
                                screenStack.add(Screen.Home)
                                currentScreen = Screen.Home
                            }
                        )
                    }

                    is Screen.Profile -> {
                        ProfileScreen(
                            currentLanguage = currentLanguage,
                            selectedCity = selectedCity,
                            onLanguageSelect = { repository.setLanguage(it) },
                            onCitySelect = { repository.setCity(it) },
                            onWorkerRegistered = { reg ->
                                repository.registerWorker(reg)
                            },
                            onWorkerCardClick = { worker ->
                                navigateTo(Screen.WorkerProfile(worker))
                            }
                        )
                    }

                    is Screen.ServiceDetail -> {
                        val categoryWorkers = repository.getWorkersForCategory(screen.serviceType)
                        ServicePageScreen(
                            serviceType = screen.serviceType,
                            workers = categoryWorkers,
                            selectedCity = selectedCity,
                            onBackClick = { navigateBack() },
                            onWorkerClick = { worker ->
                                navigateTo(Screen.WorkerProfile(worker))
                            },
                            onBookWorker = { worker ->
                                navigateTo(Screen.BookingFlow(worker))
                            },
                            onChatWorker = { worker ->
                                chatWorker = worker
                            },
                            onVideoIntroWorker = { worker ->
                                videoWorker = worker
                            }
                        )
                    }

                    is Screen.WorkerProfile -> {
                        WorkerProfileScreen(
                            worker = screen.worker,
                            onBackClick = { navigateBack() },
                            onBookClick = {
                                navigateTo(Screen.BookingFlow(screen.worker))
                            },
                            onChatClick = {
                                chatWorker = screen.worker
                            }
                        )
                    }

                    is Screen.BookingFlow -> {
                        BookingScreen(
                            worker = screen.worker,
                            selectedCity = selectedCity,
                            onBackClick = { navigateBack() },
                            onBookingConfirmed = { booking ->
                                repository.addBooking(booking)
                                screenStack.clear()
                                screenStack.add(Screen.Bookings)
                                currentScreen = Screen.Bookings
                            }
                        )
                    }
                }
            }
        }
    }
}
