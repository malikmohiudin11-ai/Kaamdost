package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ServiceType
import com.example.data.Worker
import com.example.ui.components.BoloKaamSearchBar
import com.example.ui.components.WorkerCard
import com.example.ui.theme.*

@Composable
fun SearchTabScreen(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onMicClick: () -> Unit,
    selectedCity: String,
    workers: List<Worker>,
    onWorkerClick: (Worker) -> Unit,
    onBookWorker: (Worker) -> Unit,
    onChatWorker: (Worker) -> Unit,
    onVideoIntroWorker: (Worker) -> Unit,
    onServiceTagClick: (ServiceType) -> Unit
) {
    val quickKeywords = listOf(
        "Electrician", "Plumber", "AC Service", "Solar", "Bike Ride",
        "Doctor", "Labour", "Food", "CCTV", "NADRA", "Emergency 1122"
    )

    val searchResults = remember(searchQuery, workers, selectedCity) {
        if (searchQuery.isBlank()) {
            workers
        } else {
            val q = searchQuery.lowercase().trim()
            workers.filter { worker ->
                worker.name.lowercase().contains(q) ||
                worker.nameUrdu.contains(q) ||
                worker.serviceType.titleEn.lowercase().contains(q) ||
                worker.serviceType.titleUrdu.contains(q) ||
                worker.bio.lowercase().contains(q) ||
                worker.city.lowercase().contains(q) ||
                worker.area.lowercase().contains(q)
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("search_tab_screen"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Search Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(KaamGreen)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Column {
                    Text(
                        text = "سرچ کریں • Search KaamDost",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "کوئی بھی کاریگر یا خدمت تلاش کریں",
                        color = KaamYellow,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                    BoloKaamSearchBar(
                        query = searchQuery,
                        onQueryChange = onSearchQueryChange,
                        onMicClick = onMicClick
                    )
                }
            }
        }

        // Quick Tag Chips
        item {
            Column(modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) {
                Text(
                    text = "مشہور سرچز • Popular Searches:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(quickKeywords) { keyword ->
                        Surface(
                            color = KaamGreenContainer,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.clickable {
                                onSearchQueryChange(keyword)
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = KaamGreen,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = keyword,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = KaamGreenDark
                                )
                            }
                        }
                    }
                }
            }
        }

        // Result Count
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (searchQuery.isBlank()) "تمام کاریگر • All Workers (${searchResults.size})" else "نتائج • Results for \"$searchQuery\" (${searchResults.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        }

        if (searchResults.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 40.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.SearchOff,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "کوئی کاریگر نہیں ملا • No Worker Found",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "Try searching for 'Electrician', 'Plumber', 'AC', or 'Doctor'",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            }
        } else {
            items(searchResults) { worker ->
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    WorkerCard(
                        worker = worker,
                        onCardClick = { onWorkerClick(worker) },
                        onBookClick = { onBookWorker(worker) },
                        onChatClick = { onChatWorker(worker) },
                        onVideoClick = { onVideoIntroWorker(worker) }
                    )
                }
            }
        }
    }
}
