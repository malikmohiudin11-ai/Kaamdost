package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Language
import com.example.data.SampleData
import com.example.data.ServiceType
import com.example.data.Worker
import com.example.data.WorkerRegistration
import com.example.ui.components.shareKaamDostApp
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    currentLanguage: Language,
    selectedCity: String,
    onLanguageSelect: (Language) -> Unit,
    onCitySelect: (String) -> Unit,
    onWorkerRegistered: (WorkerRegistration) -> Worker,
    onWorkerCardClick: (Worker) -> Unit
) {
    val context = LocalContext.current
    var activeMode by remember { mutableStateOf(0) } // 0 = Customer, 1 = Worker Registration

    // Worker Registration Form State
    var workerName by remember { mutableStateOf("") }
    var workerPhone by remember { mutableStateOf("") }
    var workerCity by remember { mutableStateOf(selectedCity) }
    var selectedCategory by remember { mutableStateOf(ServiceType.ELECTRICIAN) }
    var experienceYears by remember { mutableStateOf("5") }
    var workerCnic by remember { mutableStateOf("") }
    var hourlyRate by remember { mutableStateOf("600") }
    var hasPhotoSelected by remember { mutableStateOf(false) }
    var hasVideoRecorded by remember { mutableStateOf(false) }

    var newlyRegisteredWorker by remember { mutableStateOf<Worker?>(null) }
    var showSuccessBanner by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("profile_screen_column"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Header
        item {
            Surface(
                color = KaamGreen,
                shadowElevation = 3.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Text(
                        text = "پروفائل و رجسٹریشن • Profile & Register",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "گاہک یا کاریگر کے طور پر شامل ہوں",
                        color = KaamYellow,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2 Big Buttons: "Register as Customer" / "Register as Worker"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { activeMode = 0 },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("btn_register_customer"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeMode == 0) KaamYellow else Color.White.copy(alpha = 0.18f)
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "Register as Customer\nکسٹمر موڈ",
                                color = if (activeMode == 0) KaamGreenDark else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }

                        Button(
                            onClick = { activeMode = 1 },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("btn_register_worker"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeMode == 1) KaamYellow else Color.White.copy(alpha = 0.18f)
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "Register as Worker\nکاریگر بنیں",
                                color = if (activeMode == 1) KaamGreenDark else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        if (activeMode == 0) {
            // ================= CUSTOMER PROFILE TAB =================
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Customer Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(KaamGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("MU", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Muhammad Usman", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = TextPrimary)
                                Text("0300-9988776 • Customer", fontSize = 13.sp, color = TextSecondary)
                                Text("$selectedCity, Pakistan", fontSize = 12.sp, color = KaamGreenDark, fontWeight = FontWeight.Medium)
                            }
                            Surface(
                                color = KaamGreenContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "Active",
                                    color = KaamGreenDark,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    // Language Selector
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Translate, contentDescription = null, tint = KaamGreen)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "زبان منتخب کریں • Choose Language",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                            Text(
                                text = "Urdu, Pashto, Punjabi, Sindhi, Balochi, English",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                            )

                            val languages = Language.values().toList()
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                languages.forEach { lang ->
                                    val isSelected = currentLanguage == lang
                                    Surface(
                                        color = if (isSelected) KaamGreenContainer else BackgroundLight,
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, if (isSelected) KaamGreen else DividerColor),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onLanguageSelect(lang) }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                RadioButton(
                                                    selected = isSelected,
                                                    onClick = { onLanguageSelect(lang) },
                                                    colors = RadioButtonDefaults.colors(selectedColor = KaamGreen)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "${lang.nativeName} (${lang.englishName})",
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    fontSize = 14.sp,
                                                    color = if (isSelected) KaamGreenDark else TextPrimary
                                                )
                                            }
                                            if (isSelected) {
                                                Icon(Icons.Default.Check, contentDescription = null, tint = KaamGreen, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Share KaamDost App Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = KaamYellowContainer),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF6B5400))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Share KaamDost App • دوستوں کو بھیجیں",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color(0xFF5A4400)
                                )
                            }
                            Text(
                                text = "سب کام ایک ایپ میں! لنک شیئر کریں اور دوستوں کو بھی سروسز کا فائدہ پہنچائیں",
                                fontSize = 12.sp,
                                color = Color(0xFF4E3B00),
                                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                            )
                            Button(
                                onClick = { shareKaamDostApp(context) },
                                colors = ButtonDefaults.buttonColors(containerColor = KaamGreen),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().height(44.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = KaamYellow)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("kaamdost.pk/download شیئر کریں", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }

                    // Emergency Helplines
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Emergency Numbers Pakistan • ہنگامی نمبرز",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                HelplinePill("1122", "Rescue", KaamRed)
                                HelplinePill("15", "Police", KaamGreen)
                                HelplinePill("115", "Edhi", Color(0xFFE65100))
                                HelplinePill("130", "Motorway", Color(0xFF00695C))
                            }
                        }
                    }
                }
            }
        } else {
            // ================= WORKER REGISTRATION TAB =================
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Success Banner if just registered
                    if (showSuccessBanner && newlyRegisteredWorker != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = KaamGreenContainer),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = KaamGreen, modifier = Modifier.size(26.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "مبارک ہو! آپ کا پروفائل لائیو ہو گیا ہے",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = KaamGreenDark
                                    )
                                }
                                Text(
                                    text = "Your profile has been added to KaamDost. Customers in $workerCity can now book you!",
                                    fontSize = 12.sp,
                                    color = TextSecondary,
                                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                                )
                                Button(
                                    onClick = { onWorkerCardClick(newlyRegisteredWorker!!) },
                                    colors = ButtonDefaults.buttonColors(containerColor = KaamGreen),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("اپنی لائیو پروفائل دیکھیں • View Profile", color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Worker Form: Name, Phone, City, Work, Experience, Photo, Video, CNIC
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "کاریگر رجسٹریشن فارم • Worker Form",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = KaamGreenDark
                            )
                            Text(
                                text = "اپنا ہنر درج کریں اور روزانہ گاہک حاصل کریں",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
                            )

                            // 1. Name
                            OutlinedTextField(
                                value = workerName,
                                onValueChange = { workerName = it },
                                label = { Text("Full Name • پورا نام") },
                                placeholder = { Text("e.g. Ustad Tariq Khan") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("worker_reg_name")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // 2. Phone
                            OutlinedTextField(
                                value = workerPhone,
                                onValueChange = { workerPhone = it },
                                label = { Text("Phone Number • فون نمبر") },
                                placeholder = { Text("03001234567") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("worker_reg_phone")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // 3. City
                            OutlinedTextField(
                                value = workerCity,
                                onValueChange = { workerCity = it },
                                label = { Text("City • شہر") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("worker_reg_city")
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // 4. CNIC
                            OutlinedTextField(
                                value = workerCnic,
                                onValueChange = { workerCnic = it },
                                label = { Text("CNIC Number • شناختی کارڈ نمبر") },
                                placeholder = { Text("17301-1234567-1") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("worker_reg_cnic")
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // 5. Work / Service Category
                            Text(
                                text = "Work / Skill • ہنر / کام کا شعبہ:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(ServiceType.values().toList()) { service ->
                                    val isSelected = selectedCategory == service
                                    Surface(
                                        color = if (isSelected) KaamGreen else BackgroundLight,
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, if (isSelected) KaamGreen else DividerColor),
                                        modifier = Modifier.clickable { selectedCategory = service }
                                    ) {
                                        Text(
                                            text = "${service.titleUrdu} (${service.titleEn})",
                                            color = if (isSelected) Color.White else TextPrimary,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 12.sp,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // 6. Experience
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedTextField(
                                    value = experienceYears,
                                    onValueChange = { experienceYears = it },
                                    label = { Text("Exp (Years) • تجربہ") },
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = hourlyRate,
                                    onValueChange = { hourlyRate = it },
                                    label = { Text("Visit Fee (Rs.) • فیس") },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // 7. Photo Upload / Select
                            Surface(
                                color = if (hasPhotoSelected) KaamGreenContainer else BackgroundLight,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, if (hasPhotoSelected) KaamGreen else DividerColor),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        hasPhotoSelected = true
                                        Toast.makeText(context, "Photo attached successfully!", Toast.LENGTH_SHORT).show()
                                    }
                                    .testTag("worker_reg_photo_btn")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (hasPhotoSelected) Icons.Default.CheckCircle else Icons.Default.AddAPhoto,
                                        contentDescription = null,
                                        tint = if (hasPhotoSelected) KaamGreen else TextSecondary
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = if (hasPhotoSelected) "تصویر منتخب ہو گئی • Photo Attached" else "Upload Photo • تصویر اپلوڈ کریں",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (hasPhotoSelected) KaamGreenDark else TextPrimary
                                        )
                                        Text(
                                            text = "Take selfie or pick from gallery",
                                            fontSize = 11.sp,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // 8. Video Intro Recording
                            Surface(
                                color = if (hasVideoRecorded) KaamYellowContainer else BackgroundLight,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, if (hasVideoRecorded) KaamYellowDark else DividerColor),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        hasVideoRecorded = true
                                        Toast.makeText(context, "Video Intro recorded (30s)!", Toast.LENGTH_SHORT).show()
                                    }
                                    .testTag("worker_reg_video_btn")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (hasVideoRecorded) Icons.Default.VideoCall else Icons.Default.Videocam,
                                        contentDescription = null,
                                        tint = if (hasVideoRecorded) Color(0xFF6B5400) else TextSecondary
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = if (hasVideoRecorded) "ویڈیو ریکارڈ ہو گئی • 30s Video Intro Ready" else "Record Video Intro • ویڈیو تعارف ریکارڈ کریں",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (hasVideoRecorded) Color(0xFF594400) else TextPrimary
                                        )
                                        Text(
                                            text = "Brief 30-sec video showing your skill builds 3x more trust!",
                                            fontSize = 11.sp,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            // Submit Button
                            Button(
                                onClick = {
                                    if (workerName.isBlank() || workerPhone.isBlank() || workerCnic.isBlank()) {
                                        Toast.makeText(context, "Please fill Name, Phone, and CNIC", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    val registration = WorkerRegistration(
                                        fullName = workerName,
                                        phone = workerPhone,
                                        city = workerCity,
                                        serviceCategory = selectedCategory,
                                        experienceYears = experienceYears.toIntOrNull() ?: 3,
                                        cnic = workerCnic,
                                        hourlyRate = hourlyRate,
                                        hasVideoIntro = hasVideoRecorded,
                                        hasPhoto = hasPhotoSelected
                                    )
                                    val created = onWorkerRegistered(registration)
                                    newlyRegisteredWorker = created
                                    showSuccessBanner = true
                                    Toast.makeText(context, "Mubarak! Registration Submitted", Toast.LENGTH_LONG).show()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("submit_worker_registration"),
                                colors = ButtonDefaults.buttonColors(containerColor = KaamGreen),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = KaamYellow)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "رجسٹر کریں • Submit Worker Application",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HelplinePill(number: String, name: String, color: Color) {
    val context = LocalContext.current
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.clickable {
            Toast.makeText(context, "Dialing $name $number", Toast.LENGTH_SHORT).show()
        }
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(number, fontWeight = FontWeight.Black, fontSize = 16.sp, color = color)
            Text(name, fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
        }
    }
}
