package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// KaamDost Official Pakistani Brand Colors
val KaamGreen = Color(0xFF0A8A3A)        // Deep Emerald Green (Pakistan Flag inspired)
val KaamGreenDark = Color(0xFF065C26)    // Forest Green
val KaamGreenLight = Color(0xFF13B24F)   // Vibrant Leaf Green
val KaamGreenContainer = Color(0xFFE8F6ED) // Soft Tint Green

val KaamYellow = Color(0xFFFFD700)       // Vibrant Golden Yellow
val KaamYellowDark = Color(0xFFC79E00)   // Dark Gold
val KaamYellowContainer = Color(0xFFFFF9DB) // Pale Gold

val KaamOrange = Color(0xFFFF7A00)       // Alert / Urgent Orange
val KaamRed = Color(0xFFD32F2F)          // Emergency 1122 Red

val BackgroundLight = Color(0xFFF7FAF7)  // Off-white gentle canvas
val SurfaceLight = Color(0xFFFFFFFF)     // Pure white card surfaces
val TextPrimary = Color(0xFF1B2A1E)      // High contrast deep charcoal
val TextSecondary = Color(0xFF536859)    // Muted readable green-grey
val DividerColor = Color(0xFFE2EBE3)

val StarGold = Color(0xFFFFA000)
val WhatsAppGreen = Color(0xFF25D366)
val VerifiedBlue = Color(0xFF1DA1F2)
