package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ServiceType
import com.example.data.Worker
import com.example.ui.components.WorkerCard
import com.example.ui.theme.*

@Composable
fun ServicePageScreen(
    serviceType: ServiceType,
    workers: List<Worker>,
    selectedCity: String,
    onBackClick: () -> Unit,
    onWorkerClick: (Worker) -> Unit,
    onBookWorker: (Worker) -> Unit,
    onChatWorker: (Worker) -> Unit,
    onVideoIntroWorker: (Worker) -> Unit
) {
    BackHandler {
        onBackClick()
    }

    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All (تمام)", "Nearby < 2km", "Top Rated 4.8+ ★", "Verified Only")

    val filteredWorkers = remember(workers, selectedFilter) {
        when (selectedFilter) {
            "Nearby < 2km" -> workers.filter { it.distanceKm <= 2.5 }
            "Top Rated 4.8+ ★" -> workers.filter { it.rating >= 4.8f }
            "Verified Only" -> workers.filter { it.verifiedNadra }
            else -> workers
        }
    }

    Scaffold(
        topBar = {
            Surface(
                color = KaamGreen,
                shadowElevation = 3.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier.testTag("service_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(KaamYellow),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = getServiceIcon(serviceType),
                                contentDescription = null,
                                tint = KaamGreenDark,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = serviceType.titleEn,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "• ${serviceType.titleUrdu}",
                                    color = KaamYellow,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "Verified Specialists in $selectedCity (${workers.size} Available)",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Filter Chips Row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(filters) { filter ->
                            val isSelected = selectedFilter == filter
                            Surface(
                                color = if (isSelected) KaamYellow else Color.White.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.clickable { selectedFilter = filter }
                            ) {
                                Text(
                                    text = filter,
                                    color = if (isSelected) KaamGreenDark else Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("service_workers_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Service Info Alert
            item {
                Surface(
                    color = KaamGreenContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.GppGood,
                            contentDescription = null,
                            tint = KaamGreen,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "KaamDost Guarantee • تسلی بخش کام",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = KaamGreenDark
                            )
                            Text(
                                text = "تمام کاریگر نادرا تصدیق شدہ ہیں اور وزٹ کے بعد کام مکمل ہونے پر ادائیگی کریں۔",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            if (filteredWorkers.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "کوئی کاریگر اس فلٹر میں نہیں ملا",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "Try switching filters to 'All' to see all workers in $selectedCity.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }
            } else {
                items(filteredWorkers) { worker ->
                    WorkerCard(
                        worker = worker,
                        onCardClick = { onWorkerClick(worker) },
                        onBookClick = { onBookWorker(worker) },
                        onChatClick = { onChatWorker(worker) },
                        onVideoClick = { onVideoIntroWorker(worker) }
                    )
                }
            }
        }
    }
}
