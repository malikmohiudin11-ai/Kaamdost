package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Language
import com.example.data.SampleData
import com.example.data.ServiceType
import com.example.data.Worker
import com.example.ui.components.BoloKaamSearchBar
import com.example.ui.components.WorkerCard
import com.example.ui.components.shareKaamDostApp
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    currentLanguage: Language,
    selectedCity: String,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onMicClick: () -> Unit,
    onServiceClick: (ServiceType) -> Unit,
    onWorkerClick: (Worker) -> Unit,
    onBookWorker: (Worker) -> Unit,
    onChatWorker: (Worker) -> Unit,
    onVideoIntroWorker: (Worker) -> Unit,
    topWorkers: List<Worker>,
    onRegisterWorkerClick: () -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_lazy_column"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Search Bar Bolo Kaam
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(KaamGreen)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                BoloKaamSearchBar(
                    query = searchQuery,
                    onQueryChange = onSearchQueryChange,
                    onMicClick = onMicClick
                )
            }
        }

        // Language Greeting Banner
        item {
            Surface(
                color = KaamYellowContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🇵🇰", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = currentLanguage.greeting,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = KaamGreenDark
                        )
                    }
                    Text(
                        text = currentLanguage.nativeName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF6B5400)
                    )
                }
            }
        }

        // Hero Banner: "Sab Kaam Ek App Me"
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .testTag("hero_banner"),
                shape = RoundedCornerShape(18.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(KaamGreenDark, KaamGreen, KaamGreenLight)
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Surface(
                                color = KaamYellow,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "Pakistan Super App",
                                    color = KaamGreenDark,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = KaamYellow,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "100% NADRA Verified",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "سب کام ایک ایپ میں",
                            color = KaamYellow,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Sab Kaam Ek App Me",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Electrician, Plumber, AC, Rides, Doctor, Food & 10+ services at your doorstep in $selectedCity",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                        )

                        // Quick Share App link button inside banner
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onRegisterWorkerClick,
                                colors = ButtonDefaults.buttonColors(containerColor = KaamYellow),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f).height(40.dp)
                            ) {
                                Text(
                                    text = "کاریگر رجسٹر کریں",
                                    color = KaamGreenDark,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            OutlinedButton(
                                onClick = { shareKaamDostApp(context) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.height(40.dp),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = Brush.linearGradient(listOf(Color.White, Color.White))
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("kaamdost.pk", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Services Grid Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ہماری تمام خدمات • All Services",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "16 ضروری خدمات - ایک کلک پر کاریگر حاضر",
                        fontSize = 12.sp,
                        color = KaamGreenDark,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Services 4x4 Grid (All 16 services)
        item {
            val allServices = ServiceType.values().toList()
            val rows = allServices.chunked(4)

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rows.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowItems.forEach { service ->
                            ServiceGridItem(
                                service = service,
                                onClick = { onServiceClick(service) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        // If row has less than 4 items, fill space
                        if (rowItems.size < 4) {
                            repeat(4 - rowItems.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // Emergency Call Strip
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .clickable { onServiceClick(ServiceType.EMERGENCY) },
                colors = CardDefaults.cardColors(containerColor = KaamRed),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(Color.White.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Emergency,
                                contentDescription = "Emergency",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Emergency • ایمرجنسی ریسکیو 1122",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "24/7 فوری ایمبولینس، آگ، اور حادثات کی مدد",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 11.sp
                            )
                        }
                    }
                    Button(
                        onClick = { onServiceClick(ServiceType.EMERGENCY) },
                        colors = ButtonDefaults.buttonColors(containerColor = KaamYellow),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "کال 1122",
                            color = KaamRed,
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Top Rated Workers Section
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ٹاپ ریٹڈ کاریگر • Top Rated Workers",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "$selectedCity میں سب سے زیادہ پسند کیے جانے والے کاریگر",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        items(topWorkers.take(5)) { worker ->
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                WorkerCard(
                    worker = worker,
                    onCardClick = { onWorkerClick(worker) },
                    onBookClick = { onBookWorker(worker) },
                    onChatClick = { onChatWorker(worker) },
                    onVideoClick = { onVideoIntroWorker(worker) }
                )
            }
        }
    }
}

@Composable
fun ServiceGridItem(
    service: ServiceType,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .testTag("service_item_${service.name.lowercase()}")
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (service == ServiceType.EMERGENCY) Color(0xFFFFEBEE) else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Icon Container
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        if (service == ServiceType.EMERGENCY) KaamRed
                        else KaamGreenContainer
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = getServiceIcon(service),
                    contentDescription = service.titleEn,
                    tint = if (service == ServiceType.EMERGENCY) Color.White else KaamGreen,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Urdu Title
            Text(
                text = service.titleUrdu,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (service == ServiceType.EMERGENCY) KaamRed else KaamGreenDark,
                textAlign = TextAlign.Center,
                maxLines = 1
            )

            // English Title
            Text(
                text = service.titleEn,
                fontSize = 10.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

fun getServiceIcon(service: ServiceType): androidx.compose.ui.graphics.vector.ImageVector {
    return when (service) {
        ServiceType.ELECTRICIAN -> Icons.Default.Bolt
        ServiceType.PLUMBER -> Icons.Default.WaterDrop
        ServiceType.FOOD -> Icons.Default.Restaurant
        ServiceType.GROCERY -> Icons.Default.ShoppingBasket
        ServiceType.BIKE_RIDE -> Icons.Default.TwoWheeler
        ServiceType.CAR_RIDE -> Icons.Default.DirectionsCar
        ServiceType.DOCTOR -> Icons.Default.MedicalServices
        ServiceType.LABOUR -> Icons.Default.Engineering
        ServiceType.AC -> Icons.Default.AcUnit
        ServiceType.SOLAR -> Icons.Default.WbSunny
        ServiceType.CCTV -> Icons.Default.Videocam
        ServiceType.CATERING -> Icons.Default.DinnerDining
        ServiceType.VET -> Icons.Default.Pets
        ServiceType.TRACTOR -> Icons.Default.Agriculture
        ServiceType.NADRA -> Icons.Default.Badge
        ServiceType.EMERGENCY -> Icons.Default.Emergency
    }
}
