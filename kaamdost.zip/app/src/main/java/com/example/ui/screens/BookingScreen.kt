package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.Booking
import com.example.data.BookingStatus
import com.example.data.Worker
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

@Composable
fun BookingScreen(
    worker: Worker,
    selectedCity: String,
    onBackClick: () -> Unit,
    onBookingConfirmed: (Booking) -> Unit
) {
    BackHandler {
        onBackClick()
    }

    val context = LocalContext.current

    val dates = listOf(
        "Today (" + SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date()) + ")",
        "Tomorrow",
        "Day After Tomorrow"
    )
    var selectedDate by remember { mutableStateOf(dates[0]) }

    val timeSlots = listOf(
        "Morning (09:00 AM - 12:00 PM)",
        "Afternoon (12:00 PM - 03:00 PM)",
        "Evening (03:00 PM - 06:00 PM)",
        "Night (06:00 PM - 09:00 PM)",
        "⚡ Urgent (Within 30 Mins)"
    )
    var selectedTimeSlot by remember { mutableStateOf(timeSlots[0]) }

    var customerName by remember { mutableStateOf("Muhammad Usman") }
    var customerPhone by remember { mutableStateOf("03009988776") }
    var areaTown by remember { mutableStateOf("Hayatabad Phase 3") }
    var streetAddress by remember { mutableStateOf("House 14, Street 5, Near Bilal Masjid") }
    var workNotes by remember { mutableStateOf("Please bring testing tools and circuit breaker") }

    val paymentMethods = listOf("Cash on Service (کیش)", "JazzCash (جاز کیش)", "EasyPaisa (ایزی پیسہ)")
    var selectedPayment by remember { mutableStateOf(paymentMethods[0]) }

    var showConfirmationDialog by remember { mutableStateOf(false) }
    var confirmedBooking by remember { mutableStateOf<Booking?>(null) }

    if (showConfirmationDialog && confirmedBooking != null) {
        val booking = confirmedBooking!!
        Dialog(onDismissRequest = {
            showConfirmationDialog = false
            onBookingConfirmed(booking)
        }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(KaamGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = KaamYellow,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "مبارک ہو! بکنگ تصدیق ہو گئی",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = KaamGreenDark
                    )
                    Text(
                        text = "Booking Confirmed Successfully!",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        color = KaamGreenContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Booking ID:", fontSize = 12.sp, color = TextSecondary)
                                Text(booking.id, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = KaamGreenDark)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Worker:", fontSize = 12.sp, color = TextSecondary)
                                Text(booking.workerName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextPrimary)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Time:", fontSize = 12.sp, color = TextSecondary)
                                Text("${booking.date} • ${booking.timeSlot.substringBefore(" (")}", fontSize = 12.sp, color = TextPrimary)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Price:", fontSize = 12.sp, color = TextSecondary)
                                Text(booking.priceSummary, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = KaamGreenDark)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "کاریگر آپ کے دیے گئے پتے پر مقررہ وقت پر پہنچ جائیں گے۔ شکریہ!",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = {
                            showConfirmationDialog = false
                            onBookingConfirmed(booking)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("view_my_bookings_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = KaamGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("بکنگ دیکھیں • View Bookings", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            Surface(
                color = KaamGreen,
                shadowElevation = 3.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("booking_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "سروس بک کریں • Book Service",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${worker.name} (${worker.serviceType.titleUrdu})",
                            color = KaamYellow,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        },
        bottomBar = {
            Surface(
                color = Color.White,
                shadowElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Visit Charges", fontSize = 12.sp, color = TextSecondary)
                            Text(worker.priceText, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = KaamGreenDark)
                        }

                        Button(
                            onClick = {
                                if (streetAddress.isBlank() || customerPhone.isBlank()) {
                                    Toast.makeText(context, "Please enter address and phone number", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val randomId = "KD-${Random.nextInt(10000, 99999)}"
                                val newBooking = Booking(
                                    id = randomId,
                                    workerId = worker.id,
                                    workerName = worker.name,
                                    serviceType = worker.serviceType,
                                    date = selectedDate,
                                    timeSlot = selectedTimeSlot,
                                    customerName = customerName,
                                    customerPhone = customerPhone,
                                    address = "$streetAddress, $areaTown, $selectedCity",
                                    city = selectedCity,
                                    priceSummary = worker.priceText,
                                    status = BookingStatus.CONFIRMED,
                                    paymentMethod = selectedPayment,
                                    notes = workNotes
                                )
                                confirmedBooking = newBooking
                                showConfirmationDialog = true
                            },
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("confirm_booking_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = KaamGreen),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = KaamYellow)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Confirm Booking • بک کریں",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("booking_form_column"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Worker Mini Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = KaamGreenContainer)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color(worker.avatarColor)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(worker.avatarInitials, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(worker.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                            Text("${worker.serviceType.titleUrdu} • ${worker.city}", fontSize = 12.sp, color = KaamGreenDark)
                            Text("Rating: ${worker.rating} ★ (${worker.jobsDone}+ jobs)", fontSize = 11.sp, color = TextSecondary)
                        }
                        Surface(
                            color = KaamYellow,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = worker.priceText.substringBefore(" "),
                                fontWeight = FontWeight.Bold,
                                color = KaamGreenDark,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Step 1: Select Date (تاریخ منتخب کریں)
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Event, contentDescription = null, tint = KaamGreen)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("1. Select Date • تاریخ منتخب کریں", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(dates) { date ->
                                val isSelected = selectedDate == date
                                Surface(
                                    color = if (isSelected) KaamGreen else BackgroundLight,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, if (isSelected) KaamGreen else DividerColor),
                                    modifier = Modifier.clickable { selectedDate = date }
                                ) {
                                    Text(
                                        text = date,
                                        color = if (isSelected) Color.White else TextPrimary,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Step 2: Select Time Slot (وقت منتخب کریں)
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = KaamGreen)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("2. Select Time • وقت منتخب کریں", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            timeSlots.forEach { slot ->
                                val isSelected = selectedTimeSlot == slot
                                Surface(
                                    color = if (isSelected) KaamGreenContainer else BackgroundLight,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, if (isSelected) KaamGreen else DividerColor),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedTimeSlot = slot }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { selectedTimeSlot = slot },
                                            colors = RadioButtonDefaults.colors(selectedColor = KaamGreen)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = slot,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 13.sp,
                                            color = if (isSelected) KaamGreenDark else TextPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Step 3: Address & Details (پتہ اور تفصیلات)
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Home, contentDescription = null, tint = KaamGreen)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("3. Address • گھر کا پتہ", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = selectedCity,
                            onValueChange = {},
                            label = { Text("City (شہر)") },
                            readOnly = true,
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = TextSecondary) }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = areaTown,
                            onValueChange = { areaTown = it },
                            label = { Text("Area / Town (علاقہ / ٹاؤن)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("booking_area_input")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = streetAddress,
                            onValueChange = { streetAddress = it },
                            label = { Text("Street / House No / Landmark (گلی و مکان نمبر)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("booking_street_input")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = workNotes,
                            onValueChange = { workNotes = it },
                            label = { Text("Task Description (کام کی تفصیل)") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                }
            }

            // Step 4: Contact & Payment
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = KaamGreen)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("4. Customer Info & Payment", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { customerName = it },
                            label = { Text("Your Name (آپ کا نام)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = customerPhone,
                            onValueChange = { customerPhone = it },
                            label = { Text("Phone Number (فون نمبر: 03xx-xxxxxxx)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("booking_phone_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Payment Method (ادائیگی کا طریقہ):", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            paymentMethods.forEach { method ->
                                val isSelected = selectedPayment == method
                                Surface(
                                    color = if (isSelected) KaamYellowContainer else BackgroundLight,
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, if (isSelected) KaamYellowDark else DividerColor),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { selectedPayment = method }
                                ) {
                                    Text(
                                        text = method.substringBefore(" ("),
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) KaamGreenDark else TextPrimary,
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
