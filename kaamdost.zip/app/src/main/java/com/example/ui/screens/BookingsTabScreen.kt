package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Booking
import com.example.data.BookingStatus
import com.example.ui.components.launchPhoneDialer
import com.example.ui.theme.*

@Composable
fun BookingsTabScreen(
    bookings: List<Booking>,
    onStatusChange: (String, BookingStatus) -> Unit,
    onBookNewClick: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Active Bookings (جاری)", "Completed (مکمل)")

    val filtered = remember(bookings, selectedTab) {
        if (selectedTab == 0) {
            bookings.filter { it.status != BookingStatus.COMPLETED && it.status != BookingStatus.CANCELLED }
        } else {
            bookings.filter { it.status == BookingStatus.COMPLETED || it.status == BookingStatus.CANCELLED }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("bookings_tab_screen")
    ) {
        // Header
        Surface(
            color = KaamGreen,
            shadowElevation = 3.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "میری بکنگز • My Bookings",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "ٹریکنگ اور سروس ریکارڈ",
                    color = KaamYellow,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = KaamYellow,
                    indicator = {}
                ) {
                    tabs.forEachIndexed { index, title ->
                        val isSelected = selectedTab == index
                        Surface(
                            color = if (isSelected) KaamYellow else Color.White.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .padding(horizontal = 4.dp, vertical = 4.dp)
                                .clickable { selectedTab = index }
                        ) {
                            Text(
                                text = title,
                                color = if (isSelected) KaamGreenDark else Color.White,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 12.dp)
                            )
                        }
                    }
                }
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.EventNote,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (selectedTab == 0) "کوئی ایکٹو بکنگ نہیں ہے" else "کوئی پرانی بکنگ ریکارڈ نہیں ہے",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Need help with home repairs, rides, or services?",
                        fontSize = 13.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                    )
                    Button(
                        onClick = onBookNewClick,
                        colors = ButtonDefaults.buttonColors(containerColor = KaamGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("نیا کام بک کریں • Book Service", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(filtered) { booking ->
                    BookingCard(
                        booking = booking,
                        onCallClick = { launchPhoneDialer(context, "03001234567") },
                        onMarkCompleted = { onStatusChange(booking.id, BookingStatus.COMPLETED) },
                        onCancel = { onStatusChange(booking.id, BookingStatus.CANCELLED) }
                    )
                }
            }
        }
    }
}

@Composable
fun BookingCard(
    booking: Booking,
    onCallClick: () -> Unit,
    onMarkCompleted: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("booking_card_${booking.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: ID + Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(KaamGreenContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = null,
                            tint = KaamGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = booking.id,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = booking.serviceType.titleUrdu,
                            fontSize = 11.sp,
                            color = KaamGreenDark,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Status Badge
                val (badgeBg, badgeFg) = when (booking.status) {
                    BookingStatus.CONFIRMED -> KaamYellowContainer to Color(0xFF6B5400)
                    BookingStatus.ON_THE_WAY -> Color(0xFFE3F2FD) to Color(0xFF0D47A1)
                    BookingStatus.IN_PROGRESS -> KaamGreenContainer to KaamGreenDark
                    BookingStatus.COMPLETED -> Color(0xFFE8F5E9) to Color(0xFF1B5E20)
                    BookingStatus.CANCELLED -> Color(0xFFFFEBEE) to KaamRed
                }

                Surface(
                    color = badgeBg,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "${booking.status.labelUrdu} • ${booking.status.labelEn}",
                        color = badgeFg,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Details Box
            Surface(
                color = BackgroundLight,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Worker: ${booking.workerName}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Time: ${booking.date} | ${booking.timeSlot}",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Address: ${booking.address}",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Charge: ${booking.priceSummary} (${booking.paymentMethod})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = KaamGreenDark
                    )
                    if (booking.notes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "Notes: \"${booking.notes}\"",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (booking.status != BookingStatus.COMPLETED && booking.status != BookingStatus.CANCELLED) {
                    OutlinedButton(
                        onClick = onCallClick,
                        modifier = Modifier.weight(1f).height(38.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Call, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Call Worker", fontSize = 12.sp)
                    }

                    Button(
                        onClick = onMarkCompleted,
                        colors = ButtonDefaults.buttonColors(containerColor = KaamGreen),
                        modifier = Modifier.weight(1f).height(38.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Mark Done", fontSize = 12.sp, color = Color.White)
                    }
                } else {
                    Surface(
                        color = KaamGreenContainer,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "خدمت مکمل ہو چکی ہے۔ شکریہ!",
                            color = KaamGreenDark,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 12.dp)
                        )
                    }
                }
            }
        }
    }
}
