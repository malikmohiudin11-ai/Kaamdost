package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = KaamGreen,
    onPrimary = Color.White,
    primaryContainer = KaamGreenContainer,
    onPrimaryContainer = KaamGreenDark,
    secondary = KaamYellow,
    onSecondary = Color(0xFF3B2E00),
    secondaryContainer = KaamYellowContainer,
    onSecondaryContainer = Color(0xFF4C3D00),
    tertiary = KaamOrange,
    onTertiary = Color.White,
    background = BackgroundLight,
    onBackground = TextPrimary,
    surface = SurfaceLight,
    onSurface = TextPrimary,
    surfaceVariant = Color(0xFFEEF5EF),
    onSurfaceVariant = TextSecondary,
    outline = Color(0xFFB5C9B8),
    error = KaamRed,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = KaamGreenLight,
    onPrimary = Color(0xFF003914),
    primaryContainer = KaamGreenDark,
    onPrimaryContainer = Color(0xFF8EFAB1),
    secondary = KaamYellow,
    onSecondary = Color(0xFF392E00),
    secondaryContainer = Color(0xFF564500),
    onSecondaryContainer = Color(0xFFFFE082),
    tertiary = KaamOrange,
    onTertiary = Color.White,
    background = Color(0xFF0F1711),
    onBackground = Color(0xFFE3EAE4),
    surface = Color(0xFF17241A),
    onSurface = Color(0xFFE3EAE4),
    surfaceVariant = Color(0xFF213325),
    onSurfaceVariant = Color(0xFFBDD0C1),
    outline = Color(0xFF435848),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep KaamDost brand colors intact!
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
