package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class KaamDostRepository {

    private val _selectedLanguage = MutableStateFlow(Language.URDU)
    val selectedLanguage: StateFlow<Language> = _selectedLanguage.asStateFlow()

    private val _selectedCity = MutableStateFlow("Peshawar")
    val selectedCity: StateFlow<String> = _selectedCity.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _workers = MutableStateFlow<List<Worker>>(SampleData.sampleWorkers)
    val workers: StateFlow<List<Worker>> = _workers.asStateFlow()

    private val _bookings = MutableStateFlow<List<Booking>>(SampleData.sampleInitialBookings)
    val bookings: StateFlow<List<Booking>> = _bookings.asStateFlow()

    private val _registeredWorkers = MutableStateFlow<List<WorkerRegistration>>(emptyList())
    val registeredWorkers: StateFlow<List<WorkerRegistration>> = _registeredWorkers.asStateFlow()

    private val _chatMessages = MutableStateFlow<Map<String, List<ChatMessage>>>(
        mapOf(
            "w1" to listOf(
                ChatMessage("m1", "w1", "السلام علیکم بھائی جان! استاد طارق بات کر رہا ہوں۔ کیا مسئلہ ہے بجلی کا؟", "10:14 AM", false),
                ChatMessage("m2", "w1", "وعلیکم السلام، کمرے کا مین بریکر بار بار ٹرپ کر رہا ہے", "10:15 AM", true),
                ChatMessage("m3", "w1", "جی جی، کوئی شارٹ سرکٹ ہے یا اوور لوڈ ہے۔ میں ٹیسٹر اور میٹر لے کر نکلتا ہوں!", "10:16 AM", false)
            ),
            "w3" to listOf(
                ChatMessage("m4", "w3", "السلام علیکم! پانی کی موٹر کا کام ہے یا واٹر ٹینکی فٹنگ؟", "09:30 AM", false)
            )
        )
    )
    val chatMessages: StateFlow<Map<String, List<ChatMessage>>> = _chatMessages.asStateFlow()

    fun setLanguage(lang: Language) {
        _selectedLanguage.value = lang
    }

    fun setCity(city: String) {
        _selectedCity.value = city
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun getWorkerById(id: String): Worker? {
        return _workers.value.find { it.id == id }
    }

    fun getWorkersForCategory(type: ServiceType): List<Worker> {
        val all = _workers.value.filter { it.serviceType == type }
        return if (all.isNotEmpty()) all else listOf(
            Worker(
                id = "gen_${type.name.lowercase()}",
                name = "Ustad ${type.titleEn} Expert",
                nameUrdu = "ماہر ${type.titleUrdu}",
                serviceType = type,
                rating = 4.8f,
                jobsDone = 420,
                city = _selectedCity.value,
                area = "Main City Center (1.5 km)",
                distanceKm = 1.5,
                priceText = "Rs. 700 Starting",
                priceTextUrdu = "700 روپے ابتدائی فیس",
                phone = "03001234567",
                whatsapp = "923001234567",
                verifiedNadra = true,
                avatarInitials = type.name.take(2),
                avatarColor = 0xFF0A8A3A,
                videoTitle = "${type.titleEn} Service Intro Video",
                videoTranscriptUrdu = "ہماری سروس پورے پاکستان میں 24 گھنٹے دستیاب ہے۔ تسلی بخش اور معیاری کام۔",
                videoTranscriptEn = "Professional verified service available across the city with customer satisfaction guarantee.",
                experienceYears = 6,
                bio = "Verified local provider specializing in professional ${type.titleEn}.",
                bioUrdu = "نادرا تصدیق شدہ ماہر کاریگر برائے ${type.titleUrdu}",
                portfolio = listOf(
                    PortfolioItem("gp1", "Recent Project", "Quality work executed with warranty", "Work")
                ),
                reviews = SampleData.sampleReviews
            )
        )
    }

    fun addBooking(booking: Booking) {
        _bookings.value = listOf(booking) + _bookings.value
    }

    fun updateBookingStatus(bookingId: String, newStatus: BookingStatus) {
        _bookings.value = _bookings.value.map {
            if (it.id == bookingId) it.copy(status = newStatus) else it
        }
    }

    fun registerWorker(reg: WorkerRegistration): Worker {
        _registeredWorkers.value = _registeredWorkers.value + reg

        // Also create a live worker card for them so they see their live profile in the app!
        val newWorker = Worker(
            id = "worker_${System.currentTimeMillis()}",
            name = reg.fullName,
            nameUrdu = reg.fullName,
            serviceType = reg.serviceCategory,
            rating = 5.0f,
            jobsDone = 1,
            city = reg.city,
            area = "Local Area (0.5 km)",
            distanceKm = 0.5,
            priceText = if (reg.hourlyRate.isNotBlank()) "Rs. ${reg.hourlyRate} / Visit" else "Rs. 600 / Visit",
            priceTextUrdu = if (reg.hourlyRate.isNotBlank()) "${reg.hourlyRate} روپے" else "600 روپے",
            phone = reg.phone,
            whatsapp = if (reg.phone.startsWith("0")) "92" + reg.phone.substring(1) else reg.phone,
            verifiedNadra = true,
            avatarInitials = reg.fullName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString("").ifEmpty { "KD" },
            avatarColor = 0xFF0A8A3A,
            videoTitle = "Worker Introduction: ${reg.fullName}",
            videoTranscriptUrdu = "السلام علیکم! میرا نام ${reg.fullName} ہے، میں ${reg.city} میں ${reg.serviceCategory.titleUrdu} کا کام ${reg.experienceYears} سال سے کر رہا ہوں۔ شناختی کارڈ تصدیق شدہ ہے۔",
            videoTranscriptEn = "Salam! My name is ${reg.fullName}, providing ${reg.serviceCategory.titleEn} in ${reg.city} with ${reg.experienceYears} years experience.",
            experienceYears = reg.experienceYears,
            bio = "Certified worker in ${reg.serviceCategory.titleEn}. CNIC: ${reg.cnic.take(5)}*****. Available on KaamDost.",
            bioUrdu = "نادرا تصدیق شدہ کاریگر برائے ${reg.serviceCategory.titleUrdu}",
            portfolio = listOf(
                PortfolioItem("nw_1", "Initial Work Profile", "Registered on KaamDost platform with verified credentials", "Verified")
            ),
            reviews = listOf(
                Review("rev_nw", "KaamDost Verification Team", "Islamabad", 5.0f, "CNIC and contact credentials verified successfully.", "Today")
            )
        )

        _workers.value = listOf(newWorker) + _workers.value
        return newWorker
    }

    fun sendChatMessage(workerId: String, text: String) {
        val timeNow = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val userMsg = ChatMessage(
            id = "msg_${System.currentTimeMillis()}",
            workerId = workerId,
            text = text,
            timestamp = timeNow,
            isFromUser = true
        )
        val currentList = _chatMessages.value[workerId] ?: emptyList()
        val updatedMap = _chatMessages.value.toMutableMap()
        updatedMap[workerId] = currentList + userMsg
        _chatMessages.value = updatedMap
    }

    fun matchServiceFromVoice(spokenText: String): ServiceType? {
        val lower = spokenText.lowercase(Locale.ROOT)
        return when {
            lower.contains("electric") || lower.contains("bijli") || lower.contains("الیکٹریشن") || lower.contains("بجلی") || lower.contains("wiring") || lower.contains("ups") -> ServiceType.ELECTRICIAN
            lower.contains("plumb") || lower.contains("pani") || lower.contains("پلمبر") || lower.contains("پانی") || lower.contains("motor") || lower.contains("tanki") -> ServiceType.PLUMBER
            lower.contains("ac") || lower.contains("cooling") || lower.contains("اے سی") || lower.contains("ایئر کنڈیشنر") -> ServiceType.AC
            lower.contains("solar") || lower.contains("سولر") || lower.contains("inverter") || lower.contains("dhup") -> ServiceType.SOLAR
            lower.contains("bike") || lower.contains("motorcycle") || lower.contains("بائیک") || lower.contains("موٹر سائیکل") -> ServiceType.BIKE_RIDE
            lower.contains("car") || lower.contains("taxi") || lower.contains("گاڑی") || lower.contains("کار") || lower.contains("ride") -> ServiceType.CAR_RIDE
            lower.contains("doctor") || lower.contains("tabeeb") || lower.contains("ڈاکٹر") || lower.contains("ilaj") || lower.contains("checkup") -> ServiceType.DOCTOR
            lower.contains("labour") || lower.contains("mazdoor") || lower.contains("مزدور") || lower.contains("helper") || lower.contains("shifting") -> ServiceType.LABOUR
            lower.contains("food") || lower.contains("khana") || lower.contains("کھانا") || lower.contains("biryani") || lower.contains("roti") -> ServiceType.FOOD
            lower.contains("grocery") || lower.contains("sauda") || lower.contains("راشن") || lower.contains("rashan") || lower.contains("atta") -> ServiceType.GROCERY
            lower.contains("cctv") || lower.contains("camera") || lower.contains("کیمرہ") || lower.contains("security") -> ServiceType.CCTV
            lower.contains("catering") || lower.contains("degh") || lower.contains("دیگ") || lower.contains("shadi") || lower.contains("khana pakana") -> ServiceType.CATERING
            lower.contains("vet") || lower.contains("maweshi") || lower.contains("جانور") || lower.contains("cow") || lower.contains("bakri") -> ServiceType.VET
            lower.contains("tractor") || lower.contains("ٹریکٹر") || lower.contains("kheti") || lower.contains("hal") -> ServiceType.TRACTOR
            lower.contains("nadra") || lower.contains("cnic") || lower.contains("نادرا") || lower.contains("shanakhti") || lower.contains("token") -> ServiceType.NADRA
            lower.contains("emergency") || lower.contains("1122") || lower.contains("ایمرجنسی") || lower.contains("ambulance") || lower.contains("rescue") -> ServiceType.EMERGENCY
            else -> null
        }
    }
}
