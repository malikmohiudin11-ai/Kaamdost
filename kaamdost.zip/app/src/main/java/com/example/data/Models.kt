package com.example.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class ServiceType(
    val titleEn: String,
    val titleUrdu: String,
    val subtitle: String,
    val iconName: String
) {
    ELECTRICIAN("Electrician", "الیکٹریشن", "Wiring, UPS, Short Circuit", "bolt"),
    PLUMBER("Plumber", "پلمبر", "Motor, Tanki, Pipeline", "water_drop"),
    FOOD("Food Delivery", "کھانا / فوڈ", "Home cooked, Biryani, Karahi", "restaurant"),
    GROCERY("Grocery", "راشن / گروسری", "Atta, Ghee, Daal, Sabzi", "shopping_basket"),
    BIKE_RIDE("Bike Ride", "بائیک رائیڈ", "Fast & Affordable Drop", "two_wheeler"),
    CAR_RIDE("Car Ride", "کار رائیڈ", "AC & Non-AC City Taxi", "directions_car"),
    DOCTOR("Doctor Visit", "ڈاکٹر / ہوم وزٹ", "Checkup, Drip, BP, Blood Test", "medical_services"),
    LABOUR("Labour / Mazdoor", "مزدور / لیبر", "Loading, Construction, Helper", "engineering"),
    AC("AC Service", "اے سی سروس", "Gas Filling, Cooling, Cleaning", "ac_unit"),
    SOLAR("Solar Panel", "سولر پینل", "Installation, Inverter, Net Metering", "wb_sunny"),
    CCTV("CCTV Security", "سی سی ٹی وی", "Camera Install & Mobile View", "videocam"),
    CATERING("Catering / Degh", "دیگ / کیٹرنگ", "Wedding, Niaz, Shadi Daawat", "dinner_dining"),
    VET("Vet / Maweshi", "جانوروں کا ڈاکٹر", "Cow, Goat, Buffalo Health", "pets"),
    TRACTOR("Tractor & Agri", "ٹریکٹر / زرعی", "Ploughing, Land leveling, Hal", "agriculture"),
    NADRA("NADRA Sahulat", "نادرا سہولت", "Form, Token, CNIC Guidance", "badge"),
    EMERGENCY("Rescue 1122", "ایمرجنسی سروس", "Ambulance, Fire, Urgent Aid", "emergency")
}

enum class Language(
    val code: String,
    val englishName: String,
    val nativeName: String,
    val greeting: String
) {
    URDU("ur", "Urdu", "اردو", "خوش آمدید! آپ کا کیا کام ہے؟"),
    ENGLISH("en", "English", "English", "Welcome! How can we help today?"),
    PASHTO("ps", "Pashto", "پښتو", "ښه راغلاست! ستاسو څه کار دی؟"),
    PUNJABI("pa", "Punjabi", "پنجابی", "جی آیاں نوں! تہاڈا کی کم اے؟"),
    SINDHI("sd", "Sindhi", "سنڌي", "ڀلي ڪري آيا! اوهان جو ڪهڙو ڪم آهي؟"),
    BALOCHI("bal", "Balochi", "بلوچی", "وش آتکے! شما چے کار داری؟")
}

data class PortfolioItem(
    val id: String,
    val title: String,
    val description: String,
    val tag: String
)

data class Review(
    val id: String,
    val authorName: String,
    val city: String,
    val rating: Float,
    val comment: String,
    val date: String
)

data class Worker(
    val id: String,
    val name: String,
    val nameUrdu: String,
    val serviceType: ServiceType,
    val rating: Float,
    val jobsDone: Int,
    val city: String,
    val area: String,
    val distanceKm: Double,
    val priceText: String,
    val priceTextUrdu: String,
    val phone: String,
    val whatsapp: String,
    val verifiedNadra: Boolean = true,
    val avatarInitials: String,
    val avatarColor: Long,
    val videoTitle: String,
    val videoTranscriptUrdu: String,
    val videoTranscriptEn: String,
    val experienceYears: Int,
    val bio: String,
    val bioUrdu: String,
    val portfolio: List<PortfolioItem>,
    val reviews: List<Review>
)

enum class BookingStatus(val labelEn: String, val labelUrdu: String) {
    CONFIRMED("Confirmed", "بک ہو گیا"),
    ON_THE_WAY("On The Way", "راستے میں ہیں"),
    IN_PROGRESS("In Progress", "کام جاری ہے"),
    COMPLETED("Completed", "مکمل ہو گیا"),
    CANCELLED("Cancelled", "منسوخ")
}

data class Booking(
    val id: String,
    val workerId: String,
    val workerName: String,
    val serviceType: ServiceType,
    val date: String,
    val timeSlot: String,
    val customerName: String,
    val customerPhone: String,
    val address: String,
    val city: String,
    val priceSummary: String,
    val status: BookingStatus = BookingStatus.CONFIRMED,
    val paymentMethod: String = "Cash on Service (کیش)",
    val notes: String = ""
)

data class ChatMessage(
    val id: String,
    val workerId: String,
    val text: String,
    val timestamp: String,
    val isFromUser: Boolean
)

data class WorkerRegistration(
    val fullName: String,
    val phone: String,
    val city: String,
    val serviceCategory: ServiceType,
    val experienceYears: Int,
    val cnic: String,
    val hourlyRate: String,
    val hasVideoIntro: Boolean = false,
    val hasPhoto: Boolean = false
)
